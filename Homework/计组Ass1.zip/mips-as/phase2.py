from phase1 import Inst, Label, generate_symbol_table
import sys

test_file, output_file = sys.argv[1], sys.argv[2]

test_in = open(test_file, 'r').readlines()
output_fd = open(output_file, 'w')

label_table, insts = generate_symbol_table(test_in)

output_insts = []

init_addr = 0x100000

register = {
    "$zero":"00000","$at":"00001","$v0":"00010","v1":"00011",
    "$a0":"00100","$a1":"00101","$a2":"00110","$a3":"00111",
    "$t0":"01000","$t1":"01001","$t2":"01010","$t3":"01011",
    "$t4":"01100","$t5":"01101","$t6":"01110","$t7":"01111",
    "$s0":"10000","$s1":"10001","$s2":"10010","$s3":"10011",
    "$s4":"10100","$s5":"10101","$s6":"10110","$s7":"10111",
    "$t8":"11000","$t9":"11001","$k0":"11010","$k1":"11011",
    "$gp":"11100","$sp":"11101","$fp":"11110","$ra":"11111"
}

for idx, d in enumerate(insts):
    if isinstance(d[0], Inst):
        _split_inst = d[0].raw.split(' ')
        split_inst = []
        for i in _split_inst:
            if len(i) != 0:
                split_inst.append(i)
        cur_pc = d[1]
        idx = 0
        op = split_inst[idx]
        if len(op) == 0:
            continue
        inst_str = ''
        if op == 'add':
            opstring = "000000"
            funct = "100000"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'addu':
            opstring = "000000"
            funct = "100001"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'and':
            opstring = "000000"
            funct = "100100"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'div':
            opstring = "000000"
            funct = "011010"
            rd = "00000"
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'divu':
            opstring = "000000"
            funct = "011011"
            rd = "00000"
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'jalr':
            opstring = "000000"
            funct = "001001"
            # idx = idx + 1
            rd = "00000"
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'jr':
            opstring = "000000"
            funct = "001000"
            # idx = idx + 1
            rd = "00000"
            idx = idx + 1
            rs = register[split_inst[idx]]
            # idx = idx + 1
            rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'mfhi':
            opstring = "000000"
            funct = "010000"
            idx = idx + 1
            rd = register[split_inst[idx]]
            # idx = idx + 1
            # rs = register[split_inst[idx]]
            # idx = idx + 1
            # rt = register[split_inst[idx]]
            rs = "00000"
            rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'mflo':
            opstring = "000000"
            funct = "010010"
            idx = idx + 1
            rd = register[split_inst[idx]]
            # idx = idx + 1
            # rs = register[split_inst[idx]]
            # idx = idx + 1
            # rt = register[split_inst[idx]]
            rs = "00000"
            rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'mthi':
            opstring = "000000"
            funct = "010001"
            # idx = idx + 1
            # rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            # idx = idx + 1
            # rt = register[split_inst[idx]]
            rd = "00000"
            rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'mtlo':
            opstring = "000000"
            funct = "010011"
            # idx = idx + 1
            # rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            # idx = idx + 1
            # rt = register[split_inst[idx]]
            rd = "00000"
            rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'mult':
            opstring = "000000"
            funct = "011000"
            # idx = idx + 1
            # rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            rd = "00000"
            # rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'multu':
            opstring = "000000"
            funct = "011001"
            # idx = idx + 1
            # rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            rd = "00000"
            # rt = "00000"
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'nor':
            opstring = "000000"
            funct = "100111"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'or':
            opstring = "000000"
            funct = "100101"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'sll':
            opstring = "000000"
            funct = "000000"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            sa = register[split_inst[idx]]
            rs = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'sllv':
            opstring = "000000"
            funct = "000100"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'slt':
            opstring = "000000"
            funct = "101010"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'sltu':
            opstring = "000000"
            funct = "101011"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'sra':
            opstring = "000000"
            funct = "000011"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            sa = register[split_inst[idx]]
            rs = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'srav':
            opstring = "000000"
            funct = "000111"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'srl':
            opstring = "000000"
            funct = "000010"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            sa = register[split_inst[idx]]
            rs = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'srlv':
            opstring = "000000"
            funct = "000110"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'sub':
            opstring = "000000"
            funct = "100010"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'subu':
            opstring = "000000"
            funct = "100011"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'syscall':
            opstring = "000000"
            funct = "001100"
            rd = "00000"
            rs = "00000"
            rt = "00000"
            sa = "00000"
            pass
        elif op == 'xor':
            opstring = "000000"
            funct = "100110"
            idx = idx + 1
            rd = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            sa = "00000"
            inst_str = opstring + rs + rt + rd + sa + funct
            pass
        elif op == 'addi':
            opstring = '001000'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'addiu':
            opstring = '001001'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'andi':
            opstring = '001100'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'beq':
            opstring = '000100'
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'bgez':
            opstring = '000001'
            rt = '00001'
            idx = idx + 1
            rs = register[split_inst[idx]]
            rt = "00001"
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'bgtz':
            opstring = '000111'
            rt = '00000'
            idx = idx + 1
            rs = register[split_inst[idx]]
            rt = "00000"
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'blez':
            opstring = '000110'
            rt = '00000'
            idx = idx + 1
            rs = register[split_inst[idx]]
            rt = "00000"
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'bltz':
            opstring = '000001'
            rt = '00000'
            idx = idx + 1
            rs = register[split_inst[idx]]
            rt = "00000"
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'bne':
            opstring = '000101'
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc - cur_pc - 1
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lb':
            opstring = '100000'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lbu':
            opstring = '100100'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lh':
            opstring = '100001'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lhu':
            opstring = '100101'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lui':
            opstring = '001111'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm = split_inst[idx].strip()[:-1]
            rs = "00000"
            val = imm
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lw':
            opstring = '100011'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'ori':
            opstring = '001101'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'sb':
            opstring = '101000'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'slti':
            opstring = '001010'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'sltiu':
            opstring = '001011'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            rs = register[split_inst[idx]]
            idx = idx + 1
            val = int(split_inst[idx].strip())
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'sh':
            opstring = '101001'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'sw':
            opstring = '101011'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'xori':
            opstring = '001110'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lwl':
            opstring = '100010'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'lwr':
            opstring = '100110'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'swl':
            opstring = '101010'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'swr':
            opstring = '101110'
            idx = idx + 1
            rt = register[split_inst[idx]]
            idx = idx + 1
            imm, rs = split_inst[idx].strip()[:-1].split('(')
            rs = register[rs]
            val = int(imm)
            imm = bin(val if val >= 0 else val + (1 << 16))
            imm = str(imm)[2:]
            imm = '0' * (16 - len(imm)) + imm
            inst_str = opstring + rs + rt + imm
            pass
        elif op == 'j':
            opstring = '000010'
            idx = idx + 1
            b0ranch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc + init_addr
            imm = bin(val if val >= 0 else val + (1 << 24))
            imm = str(imm)[2:]
            imm = '0' * (26 - len(imm)) + imm
            inst_str = opstring + imm
            pass
        elif op == 'jal':
            opstring = '000011'
            idx = idx + 1
            branch = split_inst[idx].strip()
            loc = label_table[branch]
            val = loc + init_addr
            imm = bin(val if val >= 0 else val + (1 << 24))
            imm = str(imm)[2:]
            imm = '00' + '0' * (24 - len(imm)) + imm
            inst_str = opstring + imm
            pass
        else:
            raise RuntimeError("Unexpected opcode: {}".format(op))
        output_insts.append(inst_str)

output_fd.write('\n'.join(output_insts))
output_fd.close()
