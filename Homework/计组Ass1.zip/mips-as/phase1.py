class Inst:
    def __init__(self, s):
        self.raw = s

class Label:
    def __init__(self, s):
        self.label = s

def generate_symbol_table(lines):
    d = {}
    filtered_lines = []
    for line in lines:
        l = line
        if '#' in line:
            idx = line.index('#')
            l = line[:idx].strip()
        l = l.rstrip().replace("\t","").replace(","," ").replace("\n","")
        if len(l) != 0:
            filtered_lines.append(l)
    all_lines = []
    text_seg = 1
    relative_off = 0
    for line in filtered_lines:
        if ".data" in line:
            text_seg = 0;
        if ".text" in line and text_seg == 0:
            text_seg = 1
        if ".text" in line or ".data" in line:
            continue
        if text_seg:
            if ':' in line:
                idx = line.index(':')
                label = line[:idx].strip()
                remaining = line[idx + 1:].strip()
                d[label] = relative_off
                all_lines.append((Label(label), relative_off))
                if len(remaining) != 0:
                    all_lines.append((Inst(remaining.strip()), relative_off))
                    relative_off = relative_off + 1
            else:
                all_lines.append((Inst(line.strip()), relative_off))
                relative_off = relative_off + 1
    return d, all_lines
