#include "simulator.h"
#include <cstdint>
#include <cstdlib>
#include <stdexcept>
#include <regex>
#include <string>
#include <sys/types.h>

int isBranch = 0;

std::vector<std::string> delimiter(std::string s, std::string delimiter) {
  std::string t = s;
  std::vector<std::string> tokens;

  size_t pos = 0;
  std::string token;
  while ((pos = t.find(delimiter)) != std::string::npos) {
    token = t.substr(0, pos);
    tokens.push_back(token);
    t.erase(0, pos + delimiter.length());
  }
  tokens.push_back(t);
  return std::vector<std::string>(tokens);
}

void splitInstruct(string s, vector<string> &instruct,
                   string type) { // split an MIPS instruction, ignore the
                                  // trailing comment(if exists)
  if (type == ".asciiz" || type == ".ascii") {
    instruct.push_back(type); // just for consistency (with .word, .byte, .half)
    string ns = "";
    for(int i = 0; i < s.size() - 1; ++i){
      if(s[i] == '\\' && s[i + 1] == 'n') {
        ns = ns + "\n"; i = i + 1;
      }
      else ns = ns + s[i];
    }
    int begin = ns.find_first_of("\"");
    int end = ns.find_last_of("\"");
    instruct.push_back(ns.substr(begin + 1, end - begin - 1));
  } else if (type == ".word") {
    instruct = delimiter(s, " ");
  } else if (type == ".half"){
    instruct = delimiter(s, " ");
  } else if (type == ".byte"){
    instruct = delimiter(s, " ");
  }
}

void eraseWhitespaces(string &s) {
  s.erase(0, s.find_first_not_of(" ")); // erase the leading whitespaces
  s.erase(0, s.find_first_not_of("\t"));
  s.erase(s.find_last_not_of(" ") + 1); // erase the trailing whitespaces
  s.erase(s.find_last_not_of("\t") + 1);
}

string getFirst(string s) { // get the first word of string s
  string result;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] != ' ' && s[i] != '\n' && s[i] != '\t' && s[i] != '\0') {
      result += s[i];
    } else {
      break;
    }
  }
  return result;
}

Simulator::Simulator() {
  this->memory_pointer =
      (char *)calloc(0x600000, sizeof(char)); // allocate 0x600000 bytes memory
  this->pc =
      0x400000; // initialize program counter to the first of the instruction
  this->reg[$sp] = 0xA00000;
  this->reg[$fp] = this->reg[$sp];
  this->reg[$gp] = 0x508000;
}

Simulator::~Simulator() { free(this->memory_pointer); }

void Simulator::i_type(int instruction) {
  uint32_t instruct = static_cast<uint32_t>(instruction);
  int op = (instruct >> 26) & 0x3F;
  int rs = (instruct >> 21) & 0x1F;
  int rt = (instruct >> 16) & 0x1F;
  int im = instruct & 0xFFFF;

  switch (op) {
  case 0x08:
    addi(rs, rt, im);
    break;
  case 0x09:
    _addiu(rs, rt, im);
    break;
  case 0xc:
    _andi(rs, rt, im);
    break;
  case 0x4:
    _beq(rs, rt, im);
    break;
  case 0x05:
    _bne(rs, rt, im);
    break;
  case 0x06:
    _blez(rs, rt, im);
    break;
  case 0x24:
    _lbu(rs, rt, im);
    break;
  case 0x25:
    _lhu(rs, rt, im);
    break;
  case 0x30:
    _ll(rs, rt, im);
    break;
  case 0xf:
    _lui(rt, im);
    break;
  case 0x23:
    _lw(rs, rt, im);
    break;
  case 0xd:
    _ori(rs, rt, im);
    break;
  case 0xa:
    _slti(rs, rt, im);
    break;
  case 0xb:
    _sltiu(rs, rt, im);
    break;
  case 0x28:
    _sb(rs, rt, im);
    break;
  case 0x38:
    _sc(rs, rt, im);
    break;
  case 0x29:
    _sh(rs, rt, im);
    break;
  case 0x2b:
    _sw(rs, rt, im);
    break;
  case 0x20:
    _lb(rs, rt, im);
    break;
  case 0x21:
    _lh(rs, rt, im);
    break;  
  default:
    printf("unrecognize opcode.\n");
    throw op;
  }
}

int Simulator::im_sign_extend(int im) {
  int result = 0;
  if (im >> 15) {
    result = im | 0xFFFF0000; // signed bit = 1
  } else {
    result = im; // signed bit = 0
  }
  return result;
}
// -------------- I type -----------------

void Simulator::addi(int rs, int rt, int im) {
  int signed_ex = im_sign_extend(im);
  if (im < 0) {
    cout << "signed extend = " << signed_ex << endl;
  }
  this->reg[rt] = this->reg[rs] + signed_ex;
}

void Simulator::_addiu(int rs, int rt, int im) {
  int signed_ex = im_sign_extend(im);
  if (im < 0) {
    cout << "signed extend = " << signed_ex << endl;
  }
  this->reg[rt] = this->reg[rs] + signed_ex;
}
void Simulator::_andi(int rs, int rt, int im) {
  this->reg[rt] = this->reg[rs] & im;
}
void Simulator::_beq(int rs, int rt, int im) {
  if (this->reg[rs] == this->reg[rt]) {
    this->pc = this->pc + (im_sign_extend(im) << 2) + 4;
    isBranch = 1;
  }
}
void Simulator::_bne(int rs, int rt, int im) {
  if (this->reg[rs] != this->reg[rt]) {
    this->pc = this->pc + (im_sign_extend(im) << 2) + 4;
    isBranch = 1;
  }
}
void Simulator::_blez(int rs, int rt, int im) {
  if (this->reg[rs] <= 0) {
    this->pc = this->pc + (im_sign_extend(im) << 2) + 4;
    isBranch = 1;
  }
}

void Simulator::_lbu(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  _loaded.ud = loaded;
  this->reg[rt] = _loaded.d;
}
void Simulator::_lhu(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  _mem.d = this->memory_pointer[address + 1 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 8);
  _loaded.ud = loaded;
  this->reg[rt] = _loaded.d;
}
void Simulator::_ll(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  _mem.d = this->memory_pointer[address + 1 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 8);
  _mem.d = this->memory_pointer[address + 2 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 16);
  _mem.d = this->memory_pointer[address + 3 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 24);
  _loaded.ud = loaded;
  this->reg[rt] = _loaded.d;
}
void Simulator::_lui(int rt, int im) { this->reg[rt] = ((im & 0xFFFF) << 16); }
void Simulator::_lw(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  _mem.d = this->memory_pointer[address + 1 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 8);
  _mem.d = this->memory_pointer[address + 2 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 16);
  _mem.d = this->memory_pointer[address + 3 - BASE_ADDR];
  loaded = loaded | ((_mem.ud & 0xff) << 24);
  _loaded.ud = loaded;
  this->reg[rt] = _loaded.d;
}
void Simulator::_lb(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  int32_t value = loaded;
  if(loaded & 0b1000000) value = value | 0xffffff00;
  this->reg[rt] = value;
}

void Simulator::_lh(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded;
  _im.d = im;
  _rs.d = this->reg[rs];
  address = _im.ud + _rs.ud;
  _mem.d = this->memory_pointer[address - BASE_ADDR];
  uint32_t loaded = _mem.ud & 0xff;
  _mem.d = this->memory_pointer[address - BASE_ADDR + 1];
  loaded = loaded | ((_mem.ud & 0xFF) << 8);
  int32_t value = loaded;
  if(loaded & 0b100000000000000) value = value | 0xffff0000;
  this->reg[rt] = value;
}

void Simulator::_ori(int rs, int rt, int im) {
  this->reg[rt] = this->reg[rs] | im;
}
void Simulator::_slti(int rs, int rt, int im) {
  this->reg[rt] = this->reg[rs] < im ? 1 : 0;
}
void Simulator::_sltiu(int rs, int rt, int im) {
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _rd, _rt;
  _rs.d = this->reg[rs];
  _rt.d = im;
  _rd.d = _rs.ud < _rt.ud ? 1 : 0;
  this->reg[rt] = _rd.d;
}
void Simulator::_sb(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded, _rt;
  _im.d = im;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  address = _im.ud + _rs.ud;
  this->memory_pointer[address - BASE_ADDR] = _rt.ud & 0xFF;
}
void Simulator::_sc(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded, _rt;
  _im.d = im;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  address = _im.ud + _rs.ud;
  this->memory_pointer[address - BASE_ADDR] = _rt.ud & 0xFF;
  this->memory_pointer[address + 1 - BASE_ADDR] = (_rt.ud & 0xFF00) >> 8;
  this->memory_pointer[address + 2 - BASE_ADDR] = (_rt.ud & 0xFF0000) >> 16;
  this->memory_pointer[address + 3 - BASE_ADDR] = (_rt.ud & 0xFF000000) >> 24;
}
void Simulator::_sh(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded, _rt;
  _im.d = im;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  address = _im.ud + _rs.ud;
  this->memory_pointer[address - BASE_ADDR] = _rt.ud & 0xFF;
  this->memory_pointer[address + 1 - BASE_ADDR] = (_rt.ud & 0xFF00) >> 8;
}
void Simulator::_sw(int rs, int rt, int im) {
  uint32_t address = 0;
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _im, _mem, _loaded, _rt;
  _im.d = im;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  address = _im.ud + _rs.ud;
  this->memory_pointer[address - BASE_ADDR] = _rt.ud & 0xFF;
  this->memory_pointer[address + 1 - BASE_ADDR] = (_rt.ud & 0xFF00) >> 8;
  this->memory_pointer[address + 2 - BASE_ADDR] = (_rt.ud & 0xFF0000) >> 16;
  this->memory_pointer[address + 3 - BASE_ADDR] = (_rt.ud & 0xFF000000) >> 24;
}

// -------------- R type -----------------
void Simulator::sll(int rt, int rd, int sa) {
  printf("sll: %d--(sa:%d)->%d\n", this->reg[rt], sa, this->reg[rt] << sa);
  this->reg[rd] = this->reg[rt] << sa;
  printf("sll: rd: %d\n", this->reg[rd]);
}

void Simulator::_add(int rd, int rs, int rt) {
  this->reg[rd] = this->reg[rs] + this->reg[rt];
}

void Simulator::_addu(int rd, int rs, int rt) {
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _rd, _rt;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  _rd.ud = _rs.ud + _rt.ud;
  this->reg[rd] = _rd.d;
}
void Simulator::_and(int rd, int rs, int rt) {
  this->reg[rd] = this->reg[rs] & this->reg[rt];
}
void Simulator::_jr(int rs) {
  union {
    uint32_t ud;
    int32_t d;
  } _rs;
  _rs.d = this->reg[rs];
  this->pc = _rs.ud;
  isBranch = 1;
}
void Simulator::_nor(int rd, int rs, int rt) {
  this->reg[rd] = ~(this->reg[rs] | this->reg[rt]);
}
void Simulator::_or(int rd, int rs, int rt) {
  this->reg[rd] = this->reg[rs] | this->reg[rt];
}
void Simulator::_slt(int rd, int rs, int rt) {
  this->reg[rd] = this->reg[rs] < this->reg[rt] ? 1 : 0;
}
void Simulator::_sltu(int rd, int rs, int rt) {
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _rd, _rt;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  _rd.d = _rs.ud < _rt.ud ? 1 : 0;
  this->reg[rd] = _rd.d;
}
void Simulator::_srl(int rt, int rd, int sa) {
  printf("srl: %d--(sa:%d)->%d\n", this->reg[rt], sa, this->reg[rt] >> sa);
  this->reg[rd] = this->reg[rt] >> sa;
  
}
void Simulator::_sub(int rd, int rs, int rt) {
  this->reg[rd] = this->reg[rs] - this->reg[rt];
}
void Simulator::_subu(int rd, int rs, int rt) {
  union {
    uint32_t ud;
    int32_t d;
  } _rs, _rd, _rt;
  _rs.d = this->reg[rs];
  _rt.d = this->reg[rt];
  _rd.ud = _rs.ud - _rt.ud;
  this->reg[rd] = _rd.d;
}

void Simulator::r_type(int instruction, ifstream &ioIn, ofstream &ioOut) {
  uint32_t instruct = static_cast<uint32_t>(instruction);
  int rs = (instruct >> 21) & 0x1F;
  int rt = (instruct >> 16) & 0x1F;
  int rd = (instruct >> 11) & 0x1F;
  int sa = (instruct >> 6) & 0x1F;
  int funct = instruct & 0x3F;

  switch (funct) {
  case 0x00:
    sll(rt, rd, sa);
    break;
  case 0x20:
    _add(rd, rs, rt);
    break;
  case 0x21:
    _addu(rd, rs, rt);
    break;
  case 0x24:
    _and(rd, rs, rt);
    break;
  case 0x8:
    _jr(rs);
    break;
  case 0x27:
    _nor(rd, rs, rt);
    break;
  case 0x25:
    _or(rd, rs, rt);
    break;
  case 0x2a:
    _slt(rd, rs, rt);
    break;
  case 0x2b:
    _sltu(rd, rs, rt);
    break;
  case 0x2:
    _srl(rt, rd, sa);
    break;
  case 0x22:
    _sub(rd, rs, rt);
    break;
  case 0x23:
    _subu(rd, rs, rt);
    break;
 
  case 0x0C:
    syscall(ioIn, ioOut);
    break;
  }
}

void Simulator::syscall(ifstream &ioIn, ofstream &ioOut) {
  int v0 = this->reg[$v0];

  if (v0 == 4) { // print_string
    uint32_t addr = static_cast<uint32_t>(this->reg[$a0]);
    int i = 0;
    while (this->memory_pointer[addr + i - BASE_ADDR] !=
           '\0') { // read the null-terminated string, beginning at addr
      ioOut << this->memory_pointer[addr + i - BASE_ADDR];
      i++;
    }
    ioOut << flush;
  } else if(v0 == 10){ // exit
    ioIn.close();
    ioOut.close();
    exit(0);
  } else if(v0 == 1){ // print
    int32_t value = this->reg[$a0];
    ioOut << value << flush;
  } else if(v0 == 5){ // read
    int32_t value;
    ioIn >> value;
    this->reg[$v0] = value;
  } else if(v0 == 12){ // read
    char t;
    ioIn >> t;
    this->reg[$v0] = t;
    printf("syscall 12: %d %c\n", (int)t, (char)t);
  } else if(v0 == 11){ // print
    auto value = this->reg[$a0] & 0xFF;
    ioOut << (char) value << flush;
    printf("syscall 11: %d %c\n", value, (char)value);
  } else if(v0 == 9){
    this->reg[$v0] = this->brk;
    this->brk = this->brk + this->reg[$a0];
  } else if(v0 == 13){
    uint32_t addr = static_cast<uint32_t>(this->reg[$a0]);
    int i = 0;
    std::string name = "";
    while (this->memory_pointer[addr + i - BASE_ADDR] !=
           '\0') { // read the null-terminated string, beginning at addr
      name = name + this->memory_pointer[addr + i - BASE_ADDR];
      i++;
    }
    printf("name: %s\n", name.c_str());
    int fd = open(name.c_str(), this->reg[$a1], this->reg[$a2]);
    printf("fd: %d\n", fd);
    this->reg[$a0] = fd;
  } else if(v0 == 14){
    void *buf = this->memory_pointer + (this->reg[$a1] - BASE_ADDR);
    ssize_t v = read(this->reg[$a0], buf, this->reg[$a2]);
    this->reg[$a0] = v;
  } else if(v0 == 15){
    
    void *buf = this->memory_pointer + (this->reg[$a1] - BASE_ADDR);
    ssize_t v = write(this->reg[$a0], buf, this->reg[$a2]);
    // printf("write: %d, v: %d, fd: %d\n", this->reg[$a2], v, this->reg[$a0]);
    this->reg[$a0] = v;
  } else if(v0 == 16){
    close(this->reg[$a0]);
  } else if(v0 == 17){
    exit(this->reg[$a0]);
  } else if(v0 == 8){
    int idx = 0;
    int limit = this->reg[$a1];
    char *buf = &this->memory_pointer[this->reg[$a0] - BASE_ADDR];
    char t;
    t = ioIn.get();
    while(t == '\n') t = ioIn.get();
    printf("t: [%c]\n", t);
    while(t != '\n' && idx < limit){
      printf("idx: %d, limit: %d, t: %c\n", idx, limit, t);
      buf[idx] = t;
      idx++;
      t = ioIn.get();
    }
    buf[idx] = 0;

  } else {
    printf("syscall number: %d\n", v0);
    throw new runtime_error("unrecognized syscall");
  }
}

void Simulator::store(string asm_in, string bin_in) {
  ifstream asmIn;
  ifstream binIn;

  asmIn.open(asm_in.c_str(), ios::in);
  binIn.open(bin_in.c_str(), ios::in);

  if (asmIn.fail() || binIn.fail()) {
    cout << "Error (store): input files not open correctly" << endl;
    exit(1);
  } else {
    this->storeAsm(asmIn);
    this->storeBin(binIn);
  }
  asmIn.close();
  binIn.close();
}

void Simulator::storeAsm(ifstream &asmFile) {
  string s;
  bool flag = false; // if current line is in .data section
  int block = 0;     // current No. of 4-byte block num in virtual static memory
  while (getline(asmFile, s)) {
    eraseWhitespaces(s);
    if (!s.empty()) { // ignore blank line with leading whitespace
      if (s[0] != '#' && s[0] != '\n') {
        string first = getFirst(s);
        if (first == ".data") {
          flag = true;
          continue;
        }
        if (first == ".text") {
          flag = false;
          continue;
        }
        if (flag) { // in .data section
          int colon_pos = s.find_first_of(":");
          if (colon_pos != -1) {
            s.erase(0, colon_pos + 1); // ignore data label
            eraseWhitespaces(s);
          }
          if (!s.empty() && s[0] != '#') {
            string type = getFirst(s);
            vector<string> instruct; // instruct[0] stores the data type
            splitInstruct(s, instruct, type);

            int block_needed = 0;
            if (type == ".asciiz" || type == ".ascii") {
              string content = instruct[1];
              if (type == ".asciiz") {
                content += '\0';
              }
              int len = content.length();
              block_needed = (len % 4 == 0) ? (len / 4) : (len / 4 + 1);
              for (int i = 0; i < len; i++) {
                this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + i] =
                    content[i];
              }
            } else if(type == ".word"){
              union{
                uint32_t ud;
                int32_t d;
              } val;
              val.d = std::stoi(instruct[1]);
              this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4] = val.ud & 0xFF;
              this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + 1] = (val.ud & 0xFF00) >> 8;
              this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + 2] = (val.ud & 0xFF0000) >> 16;
              this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + 3] = (val.ud & 0xFF000000) >> 24;
              block_needed += 1;
            } else if(type == ".half"){
              auto val = delimiter(instruct[1], ",");
              auto block_cnt = val.size() / 2;
              auto remaining = val.size() % 2;
              if(remaining > 0) block_cnt = block_cnt + 1;
              union{
                uint16_t ud;
                int16_t d;
              } val_u;
              for(int i = 0; i < val.size(); ++i){
                val_u.d = std::stoi(val[i]) & 0xFFFF;
                this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + i * 2] = val_u.ud & 0xFF;
                this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + i * 2 + 1] = (val_u.ud & 0xFF00) >> 8;
              }
              block_needed += block_cnt;
            } else if(type == ".byte"){
              auto val = delimiter(instruct[1], ",");
              auto block_cnt = val.size() / 4;
              auto remaining = val.size() % 4;
              if(remaining > 0) block_cnt = block_cnt + 1;
              union{
                uint8_t ud;
                int8_t d;
              } val_u;
              for(int i = 0; i < val.size(); ++i){
                val_u.d = std::stoi(val[i]) & 0xFF;
                this->memory_pointer[STATIC_ADDR - BASE_ADDR + block * 4 + i] = val_u.ud & 0xFF;
              }
              block_needed += block_cnt;
            }
            block += block_needed;
          }
        }
      }
    }
  }
  this->dynamicEnd =
      STATIC_ADDR + block * 4; // start of dynamic = end of dynamic
  this->brk = this->dynamicEnd;
}

void Simulator::storeBin(ifstream &binFile) { // store machine code input
  string s;
  int count = 0; // count the number of instructions (for calculating address)
  while (getline(binFile, s)) {
    bitset<32> bit(s);
    unsigned int instruction = bit.to_ulong();
    for (int i = 0; i < 4; i++) {
      this->memory_pointer[count * 4 + i] = (instruction >> 8 * i) & 0xff;
    }
    count++;
  }
}

bool Simulator::pc_is_valid() {
  if (this->pc >= BASE_ADDR && this->pc < STATIC_ADDR) {
    return true;
  } else {
    return false;
  }
}

int Simulator::fetch(uint32_t pc) { // fetch the 4 bytes starting at pc and
                                    // convert it to binary string
  int result = ((int)this->memory_pointer[pc - BASE_ADDR]) & (0xff) |
               (((int)this->memory_pointer[pc + 1 - BASE_ADDR]) & (0xff)) << 8 |
               (((int)this->memory_pointer[pc + 2 - BASE_ADDR]) & 0xff) << 16 |
               (((int)this->memory_pointer[pc + 3 - BASE_ADDR]) & 0xff) << 24;

  return result;
}

void Simulator::execute(int instruction, ifstream &ioIn, ofstream &ioOut) {
  int opcode = ((static_cast<uint32_t>(instruction)) >> 26) & 0x3F;
  if (opcode == 0) {
    r_type(instruction, ioIn, ioOut);

  } else if (opcode == 2) {
    // J
    union {
      int32_t d;
      uint32_t ud;
    } op;
    op.d = instruction & 0b00000011111111111111111111111111;
    uint32_t address = op.ud;
    this->pc = ((address) << 2) | ((this->pc + 4) & (0xf0000000));
    isBranch = 1;
  } else if (opcode == 3) {
    // JAL
    union {
      int32_t d;
      uint32_t ud;
    } op;
    op.d = instruction & 0b00000011111111111111111111111111;
    uint32_t address = op.ud;
    this->reg[31] = this->pc + 4;
    this->pc = ((address) << 2) | ((this->pc + 4) & (0xf0000000));
    printf("jal: target: %d\n", (this->pc - 0x400000));
    isBranch = 1;
  } else {
    i_type(instruction);
  }
  if(!isBranch) this->pc = this->pc + 4;
  isBranch = 0;
}
